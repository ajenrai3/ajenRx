<?php
include('conn.php');


//email

	error_reporting(E_ALL ^ E_NOTICE);
	$id1 = $_GET['id'];
	$query = "SELECT * FROM client WHERE id = $id1 ";

	$result1 = mysqli_query($conn,$query);
	if($result1){


					while($row = mysqli_fetch_array($result1)){
						
						$email = $row['Email'];
						
					}
				}
				
?>



<!DOCTYPE html>
<html>
<head>
	<title>Create users</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		
		<div id="userContainer">
		<div id="form">
			<p id="para1">Send email</p>
			<form action="sendEmail.php" method="POST">
			
			<label for = "email">Email address</label><br>
			<input type="email" name="email" id="email" class="email-input" value="<?php echo $email; ?>"><br>
			
			<label for="subject">Subject</label><br>
			<input type="text" name="subject" id="subject" class="email-input" ><br>
			<label for="body">Body</label><br>
			<textarea rows="10" cols="50" name="body"></textarea><br>
			<input type="submit" name="sendEmail" value="SEND">

			
			</form>
		</div>
		<div id="DB">
			<div id = "userdbContainer">
				<p id="para1">Database of client</p>
				
			
			<table cellpadding="5" cellspacing="0" border="1px solid black" >
				<tr>
					<th>Id</th>
					<th>Fname</th>
					<th>Lname</th>
					<th>Address</th>
					<th>Email</th>
					<th>Contact Number</th>
					<th>Action</th>
				</tr>
				<?php
					// view database and pagination
					error_reporting(E_ALL ^ E_NOTICE);
					$page = $_GET['page'];

					if($page=="" || $page=="1"){
						$page1 = 0;
					} else{
						$page1 = ($page*6)-6;
					}

					$sql = "SELECT * FROM client limit $page1,6";
					$query = mysqli_query($conn,$sql);
					if(mysqli_num_rows($query)>0){

						$i=1;
						while($row=mysqli_fetch_object($query))
						{



				?>
				<tr>
					<td><?php echo $i++; ?></td>
					<td><?php echo $row->Fname;?></td>
					<td><?php echo $row->Lname;?></td>
					<td><?php echo $row->Address; ?></td>
					<td><?php echo $row->Email; ?></td>
					<td><?php echo $row->Contact_number; ?></td>
					<td><a href="adminCreate.php?id=<?php echo $row->id; ?>">Send email</a></td>
				</tr>
			<?php
				}
				//this is for counting number of page for pagination
				$sql1 = mysqli_query($conn,"SELECT * FROM client ");
					$cou = mysqli_num_rows($sql1);
			$a = $cou/6;
			$a = ceil($a);

				for($b=1;$b<=$a;$b++){

					?><a href="adminCreate.php?page=<?php echo $b; ?>" style="text-decoration:none;"><?php echo $b." ";?></a><?php 
				}		
			}
			
			
			?>
			</table>
			</div>
		</div>	
		<div class="clear"></div>
		<a href="selectionPannel.php">back to pannel</a>
		</div>

</body>
</html>