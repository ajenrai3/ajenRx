<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "green";

$conn = mysqli_connect($host,$user,$pass,$db);

