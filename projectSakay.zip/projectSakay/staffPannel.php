<?php
session_start();
include('conn.php');

$id = "";
$fname = "";
$lname = "";
$add   = "";
$email = "";
$cnum  = "";
		function getPosts(){
			error_reporting(E_ALL ^ E_NOTICE);

			$posts = array();
			if(isset($_POST['id'])){
  	 
  				$posts[0] = $_POST['id'];
 			}
			if(isset($_POST['fname'])){
  	 
  				$posts[1] = $_POST['fname'];
 			}
 			if(isset($_POST['lname'])){
				$posts[2] = $_POST['lname'];
   			}
 			if(isset($_POST['add'])){
				$posts[3] = $_POST['add'];
 			}
 			if(isset($_POST['email'])){
				$posts[4] = $_POST['email'];
 			}
			 if(isset($_POST['cnum'])){
				
 				$posts[5] = $_POST['cnum'];
			
			}
			
			
			
			
			
			return $posts;
		}

// create
		if(isset($_POST['create'])){
			$data = getPosts();
			$sql = "INSERT INTO client(id,Fname,Lname,Address,Email,Contact_number) values('$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]')";
		$result = mysqli_query($conn,$sql);
		echo "New Client user : $data[1] was created";
		}
//edit
		// if(isset($_POST['edit'])){
		// 	$data = getPosts();

		// 	$

		// }
// search
		if(isset($_POST['search'])){
			$data = getPosts();

			$search_query = "SELECT * FROM client WHERE id = $data[0]";
			$search_result = mysqli_query($conn,$search_query);

		if($search_result){

				if(mysqli_num_rows($search_result)){
					while($row = mysqli_fetch_array($search_result)){
						$id = $row['id'];
						$fname = $row['Fname'];
						$lname = $row['Lname'];
						$add = $row['Address'];
						$email = $row['Email'];
						$cnum = $row['Contact_number'];
					}
				}
				else{
					echo "no data for this id";
				}
		}
		else{
			echo "result error";
		}
	}
//edit
	error_reporting(E_ALL ^ E_NOTICE);
	$id1 = $_GET['id'];
	$query = "SELECT * FROM client WHERE id = $id1 ";

	$result1 = mysqli_query($conn,$query);
	if($result1){


					while($row = mysqli_fetch_array($result1)){
						$id = $row['id'];
						$fname = $row['Fname'];
						$lname = $row['Lname'];
						$add = $row['Address'];
						$email = $row['Email'];
						$cnum = $row['Contact_number'];
					}
				}
	if(isset($_POST['edit'])){
		$data = getPosts();
		$sql = "UPDATE client SET  Fname ='$data[1]',Lname ='$data[2]', Address = '$data[3]', Email = '$data[4]', Contact_number='$data[5]' WHERE id = $data[0]";
		$result1 = mysqli_query($conn,$sql);
		echo "ID $data[0] has been edited";
	}
				
?>



<!DOCTYPE html>
<html>
<head>
	<title>Create users</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		
		<div id="userContainer">
		<p id="para2">Welcome staff!</p>
		<div id="form">
			<p id="para1">Create User</p>
			<form action="staffPannel.php" method="POST">
			<table>
			<tr><td>
			<label for = "id">ID</label><br>
			<input type="number" name="id" id="id" class="staff-input" value="<?php echo $id; ?>">
			</td></tr>
			<tr>
			<td>
			<label for = "fname">Firstname</label><br>
			<input type="text" name="fname" id="fname" class="staff-input" value="<?php echo $fname; ?>">
			</td>
			<td>
			<label for="lname">Lastname</label><br>
			<input type="text" name="lname" id="lname" class="staff-input" value="<?php echo $lname; ?>">
			</td>
			</tr>
			</table>
			<label for="add">Address</label><br>
			<input type="text" name="add" id="add" class="staff-input" value="<?php echo $add; ?>"><br>
			<label for = "email">Email address</label><br>
			<input type="email" name="email" id="email" class="staff-input" value="<?php echo $email; ?>"><br>
			<label for="cnum">Contact Number</label><br>
			&nbsp;<input type="text" name="cnum" id="num" class="staff-input" value="<?php echo $cnum; ?>"><br><br>
			<input type="submit" name="create" value="Register">
			<input type="submit" name="search" value="Search">
			<input type="submit" name="edit" value="Edit">
			
			</form>
		</div>
		<div id="DB">
			<div id = "userdbContainer">
				<p id="para1">Database of client</p>
			
			<table cellpadding="5" cellspacing="0" border="1px solid black" >
				<tr>
					<th>Id</th>
					<th>Fname</th>
					<th>Lname</th>
					<th>Address</th>
					<th>Email</th>
					<th>Contact Number</th>
					<th>Action</th>
				</tr>
				<?php
					error_reporting(E_ALL ^ E_NOTICE);
					$page = $_GET['page'];

					if($page=="" || $page=="1"){
						$page1 = 0;
					} else{
						$page1 = ($page*6)-6;
					}

					$sql = "SELECT * FROM client limit $page1,6";
					$query = mysqli_query($conn,$sql);
					if(mysqli_num_rows($query)>0){

						$i=1;
						while($row=mysqli_fetch_object($query))
						{



				?>
				<tr>
					<td><?php echo $i++; ?></td>
					<td><?php echo $row->Fname;?></td>
					<td><?php echo $row->Lname;?></td>
					<td><?php echo $row->Address; ?></td>
					<td><?php echo $row->Email; ?></td>
					<td><?php echo $row->Contact_number; ?></td>
					<td><a href="staffPannel.php?id=<?php echo $row->id; ?>">Edit</a></td>
				</tr>
			<?php
				}
				//this is for counting number of page
				$sql1 = mysqli_query($conn,"SELECT * FROM client ");
					$cou = mysqli_num_rows($sql1);
			$a = $cou/6;
			$a = ceil($a);

				for($b=1;$b<=$a;$b++){

					?><a href="staffPannel.php?page=<?php echo $b; ?>" style="text-decoration:none;"><?php echo $b." ";?></a><?php 
				}		
			}
			
			
			?>
			</table>
			</div>
		</div>	
		<div class="clear"></div>
		<a href="logout.php">LOGOUT</p>
		</div>

</body>
</html>