<?php
$uname = $_POST['uname'];
$pass = $_POST['pass'];

if($uname == ("admin") && $pass == ("admin") ){

	$_SESSION['uname'] = "uname";
	$_SESSION['pass'] = "pass";
	header("location:selectionPannel.php");
}
else
	echo "Please enter the correct username and password";