<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		<div id="mainContainer">
			<p id="para1">Welcome to Admin login pannel.</p>
			<form action="adminCheck.php" method="POST">
			<div  id="username">
				<label for="uname" class="label">Username
			</label>
				<input type="text" name="uname" id="uname" class="input">
			</div>
			<div id="pass">
				<label for="pass" class="label">Password</label>
				<input type="password" name="pass" id="pass" class="input">
			</div>
			<div id="login">
				<input type="submit" name="submit" value="Login" id="submit">
			</div>
			<div id="back">
					<a href="index.php">Back</p>
			</div>
			
		</div>
</body>
</html>