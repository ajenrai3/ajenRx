<?php
	include "classes/class.phpmailer.php";   // include the class name
	$mail = new PHPMailer(); // create a new object
	$mail->IsSMTP();// enable SMTP
	$mail->SMTPDebug = 1; // debugging 1 : error and msg ,2 is only msg
	$mail->SMTPAuth = true; // authentication enabled
	$mail->SMTPSecure = 'ssl'; //secure transfer enabled Require for Gmail.
	$mail->Host = "smtp.gmail.com";
	$mail->Port = 587; // or 465
	$mail->IsHTML(true);
	$mail->Username = "please enter your email";//gmail account here
	$mail->Password = "please input your password";//password here
	$mail->SetFrom("email please");
	$mail->Subject=$_POST['subject'];
	$mail->Body=$_POST['body'];
	$mail->AddAddress($_POST['email']);
	if(!$mail->Send())
	{
			echo "Mailer Error: " . $mail->ErrorInfo;
	}
	else
	{
		echo "Message has been sent";
	}


?>