<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		<div id="mainContainer">
			<p id="para1">Please click to login</p>
			<div class="selectBox" id="admin"><a href="adminLogin.php">ADMIN</a></div>
			<div class="selectBox" id="staff"><a href="staffLogin.php">STAFF</a></div>
			
		</div>
</body>
</html>