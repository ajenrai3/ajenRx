<?php
	session_start();

	if(isset($_SESSION['pass'])){

		header("location:index.php");
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Admin Selection Pannel</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		<div id="mainContainer">
			<div id="labelpara1"><p id="para1">Please click to select.</p></div>
			<div class="selectBox" id="admin"><a href="adminCreate.php">User Database</a></div>
			<div class="selectBox" id="staff"><a href="staffCreate.php">Staff Database</a></div>
			<div id="logout"><a href="logout.php">Logout</a></div>
			
		</div>
</body>
</html>