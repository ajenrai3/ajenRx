<?php
 error_reporting(E_ALL ^ E_NOTICE);
 if(isset($_POST['fname'])){
  	 $fname = $_POST['fname'];
 }
 if(isset($_POST['lname'])){
	$lname = $_POST['lname'];
 }
 if(isset($_POST['uname'])){
	$uname = $_POST['uname'];
 }
 if(isset($_POST['pass'])){
	$pass  = $_POST['pass'];
 }
 if(isset($_POST['pass2'])){
	$pass2  = $_POST['pass2'];
 }



	if($pass == $pass2){

		include('conn.php');

		$sql = "INSERT INTO users(UserID,Fname,Lname,Username,Password) values('','$fname','$lname','$uname','$pass2')";
		$result = mysqli_query($conn,$sql);
		echo "Staff user created";
	}else{

		echo "Your password don't match";
	}
 
?>

<!DOCTYPE html>
<html>
<head>
	<title>Create Staff</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		
		<div id="staff-mainContainer">
			<p id="para1">Create Staff</p>
			<form action="staffCreate.php" method="POST">
			<table>
			<tr>
			<td>
			<label for = "fname">Firstname</label><br>
			<input type="text" name="fname" id="fname" class="staff-input">
			</td>
			<td>
			<label for="lname">Lastname</label><br>
			<input type="text" name="lname" id="lname" class="staff-input">
			</td>
			</tr>
			</table>
			<label for="uname">Username</label><br>
			<input type="text" name="uname" id="uname" class="staff-input"><br>
			<label for = "pass">Password</label><br>
			<input type="password" name="pass" id="pass" class="staff-input"><br>
			<label for="pass2">Confirm-password</label><br>
			&nbsp;<input type="password" name="pass2" id="pass2" class="staff-input"><br><br>
			<input type="submit" name="submit" value="Register">
			<a href="selectionPannel.php">back to pannel</a>
			
			</form>
		</div>

</body>
</html>