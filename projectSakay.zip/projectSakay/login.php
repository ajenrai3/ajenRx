<?php
	session_start();

	include ('conn.php');
	
		
	if(isset($_POST['uname'])){
		$uname = $_POST['uname'];
		$pass = $_POST['pass'];
		$sql = "SELECT * FROM users WHERE Username = '".$uname."' AND Password = '".$pass."' LIMIT 1";
		$res = mysqli_query($conn,$sql);

		if(mysqli_num_rows($res) == 1){
			header('location:staffPannel.php');
		}else{
			echo "you are not logged in";
		}
	}
?>